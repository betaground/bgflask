## Problem explanation

<!-- What is wrong? -->


## Steps to reproduce

<!-- If possible please show a minimal example to reproduce the issue -->

## Environment info

Operating System: <!-- e.g. Ubuntu 14.04, OSX 10.12 Sierra, Windows 10 -->
Python version: <!-- x.y.z (command: python --version) -->
Library version: <!-- x.y.z (command: pip freeze | grep stream-python) -->


## Error traceback (if applicable)

```
[put traceback here]
```

## Code snippet that causes the problem

```python
[put code here]
```
